<?php
/**
 * Created by PhpStorm.
 * User: antiprovn
 * Date: 9/23/14
 * Time: 11:30 AM
 */
return array(
    'mail' => array(
        'transport' => array(
            'options' => array(
                'host'              => 'smtp.gmail.com',
                'connection_class'  => 'plain',
                'connection_config' => array(
                    'username' => 'enjoy3013@gmail.com',
                    'password' => '15053005ct',
                    'ssl' => 'tls'
                ),
            ),
        ),
    ),
);