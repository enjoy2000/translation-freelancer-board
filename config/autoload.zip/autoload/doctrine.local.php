<?php
/**
 * Created by PhpStorm.
 * User: antiprovn
 * Date: 9/22/14
 * Time: 11:48 AM
 */
return array(
    'doctrine' => array(
        'connection' => array(
            'orm_default' => array(
                'driverClass' =>'Doctrine\DBAL\Driver\PDOMySql\Driver',
                'params' => array(
                    'host'     => '127.0.0.1',
                    'port'     => '3306',
                    'user'     => 'root',
                    'password' => '',
                    'dbname'   => 'papertask',
                )
            )
        )
    )
);