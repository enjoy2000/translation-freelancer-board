<?php
/**
 * Created by PhpStorm.
 * User: antiprovn
 * Date: 9/22/14
 * Time: 7:26 AM
 */

return array(
    'db' => array(
        'driver'    => 'PdoMysql',
        'database'  => 'papertask',
        'username'  => 'root',
        'password'  => '',
        'hostname'  => 'localhost',
    ),
    'service_manager' => array(
        'factories' => array(
            'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
        ),
    ),
);
