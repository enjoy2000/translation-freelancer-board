<?php
/**
 * Created by PhpStorm.
 * User: antiprovn
 * Date: 9/22/14
 * Time: 7:23 AM
 */

return array(
    'service_manager' => array(
        'invokables' => array(
            'Zend\Session\SessionManager' => 'Zend\Session\SessionManager',
        ),
    ),
);